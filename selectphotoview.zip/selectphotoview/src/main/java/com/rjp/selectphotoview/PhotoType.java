package com.rjp.selectphotoview;

/**
 * @author Gimpo create on 2018/1/25 11:39
 *         email : jimbo922@163.com
 */

public class PhotoType {

    public static final int TYPE_ADD_PICTURE = 11;
    public static final int TYPE_IMAGE = 21;
    public static final int TYPE_AUDIO = 31;
    public static final int TYPE_VIDEO = 41;

}
